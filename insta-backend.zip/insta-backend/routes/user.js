const express = require("express");
const {
    userById,
    allUsers,
    getUser,
    addFollowing,
    addFollower,
    removeFollowing,
    removeFollower,
    userPhoto,
    searchUsers,
    hasAuthorization
} = require("../controllers/user");
const { requireSignin } = require("../controllers/auth");

const router = express.Router();

router.put("/user/follow", requireSignin, addFollowing, addFollower);
router.put("/user/unfollow", requireSignin, removeFollowing, removeFollower);
router.get("/users/search", searchUsers);
router.get("/users", allUsers);
router.get("/user/:userId",
    requireSignin,
    getUser);

// photo
//router.get("/user/photo/:userId", userPhoto);
// who to follow


// any route containing :userId, our app will first execute userByID()
router.param("userId", userById);

module.exports = router;
