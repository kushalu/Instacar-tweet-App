const express = require("express");
const {
    getTwits,
    createTwit,
    twitsByUser,
    twitById,
    isTwiter,
    searchTwits,
    deleteTwit,
    getTwitsById,
    singleTwit,
    like,
    unlike,
    comment,
    uncomment
} = require("../controllers/twit");
const { requireSignin } = require("../controllers/auth");
const { userById } = require("../controllers/user");
const { createPostValidator } = require("../validator");

const router = express.Router();

router.get("/twits", getTwits);
router.get("/gbi/:userId", getTwitsById)
router.get("/twits/search", searchTwits);

// like unlike
router.put("/post/like", requireSignin, like);
router.put("/post/unlike", requireSignin, unlike);

// comments
router.put("/post/comment", comment);
router.put("/post/uncomment", uncomment);

// post routes
router.post(
    "/twit",
    // requireSignin,
    createTwit,
    // createPostValidator
);
router.get("/posts/by/:userId",
    requireSignin, twitsByUser);
router.get("/post/:postId", singleTwit);
/*router.put("/post/:postId",
    requireSignin,
    isTwiter,
    updateTwit);*/
router.delete("/post/:postId", requireSignin, isTwiter, deleteTwit);
// photo
//router.get("/post/photo/:postId", photo);

// any route containing :userId, our app will first execute userById()
router.param("userId", userById);
// any route containing :postId, our app will first execute postById()
router.param("postId", twitById);

module.exports = router;
