step1: install node modules : npm install
step2: after installation :nodemon app.js

