const Twit = require("../models/twit");

const _ = require("lodash");

exports.twitById = (req, res, next, id) => {
    Twit.findById(id)
        .populate("postedBy", "_id name")
        .populate("comments.postedBy", "_id name")
        .populate("postedBy", "_id name role")
        .select("_id title body created likes")
        .exec((err, post) => {
            if (err || !post) {
                return res.status(400).json({
                    error: err
                });
            }
            req.post = post;
            next();
        });
};

/*
exports.getPosts = (req, res) => {
    const posts = Post.find()
        .populate("postedBy", "_id name")
        .populate("comments", "text created")
        .populate("comments.postedBy", "_id name")
        .select("_id title body created likes")
        .sort({ created: -1 })
        .then(posts => {
            res.json(posts);
        })
        .catch(err => console.log(err));
};
*/

// with pagination
exports.getTwits = async (req, res) => {
    // get current page from req.query or use default value of 1
    const currentPage = req.query.page || 1;
    // return 3 posts per page
    const perPage = 10;
    let totalItems;
    var arr = []
    const posts = await Twit.find()
        // countDocuments() gives you total count of posts
        .countDocuments()
        .then(count => {
            totalItems = count;
            return Twit.find()
                .skip((currentPage - 1) * perPage)
                /*.populate("comments", "text created")
                .populate("comments.postedBy", "_id name")*/
                .populate("postedBy", "_id name email ")
                //.select(" twit created likes")
                .select("-_id")
                .limit(perPage)
                .sort({ created: -1 });
        })
        .then(posts => {
            res.status(200).json(posts);
            //console.log(posts)
            arr.push(posts)
        })
        .catch(err => console.log(err));

    //console.log(arr + "inside arr")
    //var arr1 = ...arr
    // arr1 = arr
    // console.log(arr1)
    //console.log(...arr)
    //arr = arr.join()
    //arr1 = []

    //arr1 = arr.split()
    console.log(...arr)

    var i;
    while (i < arr.length) {

        // arr = arr.splice(i, 1)
        console.log(arr[i])

        i++


    }
    // res.status(200).json(...arr)
    /* await Twit.insertMany(...arr1, (err, result1) => {
         //  Purchasemaster.insertMany(req.body, req.profile._id, (err, result1) => {
 
         if (err) {
             return res.status(400).json({
                 error: err
             });
         res.json(result1);
     })*/

};


exports.createTwit = (req, res, next) => {



    let post = new Twit(req.body);
    console.log(post)

    // req.profile.hashed_password = undefined;
    // req.profile.salt = undefined;
    // post.postedBy = req.profile;


    post.save((err, result) => {
        if (err) {
            return res.status(400).json({
                error: err
            });
        }
        res.json(result);
    });
    //});
};

exports.twitsByUser = (req, res) => {
    Twit.find({ postedBy: req.profile._id })
        .populate("postedBy", "_id name")
        .select("_id title body created likes")
        .sort("_created")
        .exec((err, posts) => {
            if (err) {
                return res.status(400).json({
                    error: err
                });
            }
            res.json(posts);
        });
};

exports.isTwiter = (req, res, next) => {
    let sameUser =
        req.post && req.auth && req.post.postedBy._id == req.auth._id;


    console.log("req.post ", req.post, " req.auth ", req.auth);
    console.log("SAMEUSER: ", sameUser, " ADMINUSER: ", adminUser);

    let isPoster = sameUser

    if (!isPoster) {
        return res.status(403).json({
            error: "User is not authorized"
        });
    }
    next();
};



/*exports.updateTwit = (req, res, next) => {



    // save post
    let post = req.post;
    post = _.extend(post, fields);
    post.updated = Date.now();


    post.save((err, result) => {
        if (err) {
            return res.status(400).json({
                error: err
            });
        }
        res.json(post);
    });

}; */

exports.deleteTwit = (req, res) => {
    let post = req.post;

    Twit.findByIdAndDelete(
        { _id: post },

        { new: true }
    ).exec((err, result) => {
        if (err) {
            return res.status(400).json({
                error: err
            });
        } else {
            res.json(result);
        }
    });

};



exports.singleTwit = (req, res) => {
    return res.json(req.post);
};

exports.like = (req, res) => {
    Twit.findByIdAndUpdate(
        req.body.postId,
        { $push: { likes: req.body.userId } },
        { new: true }
    ).exec((err, result) => {
        if (err) {
            return res.status(400).json({
                error: err
            });
        } else {
            res.json(result);
        }
    });
};

exports.unlike = (req, res) => {
    Twit.findByIdAndUpdate(
        req.body.postId,
        { $pull: { likes: req.body.userId } },
        { new: true }
    ).exec((err, result) => {
        if (err) {
            return res.status(400).json({
                error: err
            });
        } else {
            res.json(result);
        }
    });
};

exports.comment = async (req, res) => {
    console.log("inside comment")
    let comment = req.body.comment;
    comment.postedBy = req.body.userid;

    console.log(comment)
    console.log(req.body.postid)
    await Twit.findByIdAndUpdate(
        //_id:
        req.body.postid,

        //{ $push: { comments:  comment }} ,
        {
            $push: {
                comments: {
                    $each: [{ comment: comment, postedBy: req.body.userid }],
                    $sort: { created: -1 },
                    // $slice: 3
                }
            }
        },
        { new: true }
    )
        // .populate("comments.postedBy", "_id name")
        .populate("postedBy", "_id name")
        .exec((err, result) => {
            if (err) {
                return res.status(400).json({
                    error: err
                });
            } else {
                res.json(result);
                console.log(result)
            }
        });
};

exports.uncomment = (req, res) => {
    console.log("inside un comment")
    //let comment = req.body.comment;
    console.log(req.body)
    Twit.findByIdAndUpdate(
        req.body.twitId,
        { $pull: { comments: { _id: req.body.commentId } } },
        { new: true }
    )
        // .populate("comments.postedBy", "_id name")
        //.populate("postedBy", "_id name")
        .exec((err, result) => {
            if (err) {
                return res.status(400).json({
                    error: err
                });
            } else {
                res.json(result);
                console.log(result)
            }
        });
};
exports.searchTwits = (req, res) => {
    console.log("inside twits")
    const query = {};


    console.log(req.query.search)

    if (req.query.search) {

        query.twit = {
            $regex: req.query.search, $options: 'i'
        };


        /*Twit.find(query, (err, users) => {
            if (err) {
                return res.status(400).json({
                    error: "Did not get any twit "
                });
            }
            res.json(users).populate("postedBy", "_id name")
            console.log(users)
        })*/
        Twit.find(
            query
        )

            .populate("postedBy", "_id name email")
            .exec((err, result) => {
                if (err) {
                    return res.status(400).json({
                        error: err
                    });
                } else {
                    res.json(result);
                }
            });
    }
}
/*exports.gettwit = (req, res) => {


    

}*/
exports.getTwitsById = (req, res) => {
    console.log("inside get twits")
    const pid = req.params.userId
    console.log(pid)
    Twit.find({ postedBy: pid })/*.exec(((err, users) => {

        if (err) {
            return res.status(400).json({
                error: err
            });
        }
        res.json(users);
        console.log(users)

    }))*/
        .populate("comments.postedBy", "_id name email")
        .exec((err, result) => {
            if (err) {
                return res.status(400).json({
                    error: err
                });
            } else {
                res.json(result);
                console.log(result)
            }
        })
        .sort({ postedBy: -1 });
};