var aws = require('aws-sdk')
var express = require('express')
var multer = require('multer')
var multerS3 = require('multer-s3')

var app = express()

aws.config.update({
  secretAccessKey: 'mMouAyhkzCzya+mcVfpM0OKmZC0HXdy8cydKeFi8',
  accessKeyId: 'AKIAIPOW7SUTQ24BOXUA',
  region: 'us-east-2'
})
var s3 = new aws.S3({ /* ... */ })

var upload = multer({
  storage: multerS3({
    s3: s3,
    bucket: 'youtubeq-images',
    // acl: 'public-read',
    acl: 'public-read',
    metadata: function (req, file, cb) {
      cb(null, { fieldName: "TESTING META DATA" });
    },
    key: function (req, file, cb) {
      cb(null, Date.now().toString())
    }
  })
})

app.post('/upload', upload.array('photos', 3), function (req, res, next) {
  res.send('Successfully uploaded ' + req.files.length + ' files!')
})

module.exports = upload


/*const s3 = new aws.S3();

const fileFilter = (req, file, cb) => {
  if (file.mimetype === 'image/jpeg' || file.mimetype === 'image/jpg') {
    cb(null, true)
  } else {
    cb(new Error('Invalid Mime Type, only JPEG and PNG'), false);
  }
}

const upload = multer({
  fileFilter,
  storage: multerS3({
    s3,
    bucket: 'youtubeq-images',
    // acl: 'public-read',
    metadata: function (req, file, cb) {
      cb(null, { fieldName: 'TESTING_META_DATA!' });
    },
    key: function (req, file, cb) {
      cb(null, Date.now().toString())
    }
  })
})

module.exports = upload;*/