const mongoose = require("mongoose");
const { ObjectId } = mongoose.Schema;

const tweetSchema = new mongoose.Schema({
    twit: {
        type: String,
        required: true
    },

    postedBy: {
        type: ObjectId,
        ref: "User",
        required: true
    },
    created: {
        type: Date,
        default: Date.now
    },
    updated: Date,
    likes: [{ type: ObjectId, ref: "User" }],
    comments: [
        {
            comment: String,
            created: { type: Date, default: Date.now },
            postedBy: { type: ObjectId, ref: "User" }
        }
    ]
});

module.exports = mongoose.model("Twit", tweetSchema);
