import React, { Component } from 'react';
import { signup } from "../auth";
import { Link } from "react-router-dom";
class Twitter extends Component {
  constructor() {
    super()
    this.state = {
      name: "",
      email: "",
      password: "",

      error: ""
    }
  }
  handleChange = (name) => (event) => {
    this.setState({ error: "" })//-> when user inserting a input after getting error it will vanish by itself 
    this.setState({ [name]: event.target.value })
  };
  clickSubmit = event => {
    event.preventDefault()// to not to reload by defualt 


    const { name, email, password } = this.state;
    // now to create object and send it to the backend 

    const user = {
      name,
      email,
      password
    }
    //console.log(user);

    signup(user).then(data => {
      if (data.error) this.setState({ error: data.error });
      else
        this.setState({
          error: "",
          name: "",
          email: "",
          password: "",
          open: true
        })
    })
  };

  // signup = (user) => {
  //   //  return fetch("http://localhost:8080/signup",
  //   return fetch(`${process.env.REACT_APP_API_URL}/signup`,
  //     {// we are using curly brace and the function as to return  ->> so used return keyword 
  //       method: "POST",
  //       headers: {
  //         Accept: "application/json",
  //         "Content-type": "application/json"
  //       },
  //       body: JSON.stringify(user)
  //     })
  //     .then(response => {
  //       return response.json()
  //     })
  //     .catch(err => console.log(err));
  // }
  signupForm = (name, email, password) => (
    <form>
      <div className="form-group">
        <lable className="text-muted">Name</lable>
        <input onChange={this.handleChange("name")} type="text" className="form-control" value={name} />
      </div>
      <div className="form-group">
        <lable className="text-muted">Email</lable>
        <input onChange={this.handleChange("email")} type="email" className="form-control" value={email} />
      </div>
      <div className="form-group">
        <label className="text-muted">Password</label>
        <input onChange={this.handleChange("password")} type="password" className="form-control" value={password} />
      </div>
      <button onClick={this.clickSubmit} className="btn btn-raised btn-primary">
        Submit
         </button>
    </form>
  )
  render() {
    const { name, email, password, error, open } = this.state
    return (
      <div className="container">
        <h2 className="mt-5 mb-5">Signup</h2>
        <div className="alert alert-danger" style={{ display: error ? " " : "none" }}>
          {error}
        </div>


        <div className="alert alert-info " style={{ display: open ? " " : "none" }}>
          You are successfully registered please login   !!{''}
          <Link to="/signin">Sign In</Link>.
        </div>
        {this.signupForm(name, email, password)}
        {/* passing variables as arguments  in the above   */}
      </div>
    );


  }
}
export default Twitter 