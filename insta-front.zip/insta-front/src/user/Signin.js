import React, { Component } from 'react';
//import { Redirect } from 'rect-router-dom';
import { signin } from "../auth";
import { Redirect } from "react-router-dom";

class Signin extends Component {
  constructor() {
    super()
    this.state = {
      email: "",
      password: "",
      error: "",
      redirectToReferer: false,
      loading: false // by default loading is false 

    }
  }
  handleChange = (name) => (event) => {
    this.setState({ error: "" })//-> when user inserting a input after getting error it will vanish by itself 
    this.setState({ [name]: event.target.value })
  };
  authenticate(jwt, next) {
    if (typeof window !== "undefined") {
      localStorage.setItem("jwt", JSON.stringify(jwt))//it stores in a local storage  
      next();
    }
  }
  clickSubmit = event => {
    event.preventDefault()// to not to reload by defualt 
    this.setState({ loading: true });

    const { email, password } = this.state;
    // now to create object and send it to the backend 

    const user = {

      email,
      password
    }
    console.log(user);

    signin(user).then(data => {
      if (data.error) this.setState({ error: data.error, loading: false });
      else
        this.authenticate(data, () => {
          this.setState({ redirectToReferer: true })// call back function 
        })
      //})
    })
  };

  // signin = (user) => {
  //   return fetch("http://localhost:8080/signin", {// we are using curly brace and the function as to return  ->> so used return keyword 
  //     method: "POST",
  //     headers: {
  //       Accept: "application/json",
  //       "Content-type": "application/json"
  //     },
  //     body: JSON.stringify(user)
  //   })
  //     .then(response => {
  //       return response.json()
  //     })
  //     .catch(err => console.log(err));
  // }
  signinForm = (email, password) => (
    <form>

      <div className="form-group">
        <lable className="text-muted">Email</lable>
        <input onChange={this.handleChange("email")} type="email" className="form-control" value={email} />
      </div>
      <div className="form-group">
        <label className="text-muted">Password</label>
        <input onChange={this.handleChange("password")} type="password" className="form-control" value={password} />
      </div>
      <button onClick={this.clickSubmit} className="btn btn-raised btn-primary">
        Submit
         </button>
    </form>
  )
  render() {
    const { email, password, error, redirectToReferer, loading } = this.state

    if (redirectToReferer) {
      return <Redirect to="/" />
    }

    return (
      <div className="container">
        <h2 className="mt-5 mb-5">Signin</h2>
        <div className="alert alert-danger" style={{ display: error ? " " : "none" }}>
          {error}
        </div>
        {loading ? <div className="jumbotron text-center">
          <h2>Loading ...</h2>
        </div> : (" ")}

        {this.signinForm(email, password)}
      </div>


    );


  }
}
export default Signin;

