import React, { Component } from "react";
import { isAuthenticated } from "../auth";
import { Redirect, Link } from "react-router-dom";
import { read, getTwitbi, addcomment, removecomment } from "./apiUser";
import DefaultProfile from "../images/avatar.png";
import DeleteUser from "./DeleteUser";
import FollowProfileButton from "./FollowProfileButton";
import ProfileTabs from "./ProfileTabs";
import { listByUser } from "../post/apiPost";


class Profile extends Component {
  constructor() {
    super();
    this.state = {
      user: { following: [], followers: [] },
      redirectToSignin: false,
      following: false,
      error: "",
      posts: [],
      twits: [],
      comment: "",

    };
  }

  // check follow
  checkFollow = user => {
    const jwt = isAuthenticated();
    const match = user.followers.find(follower => {
      // one id has many other ids (followers) and vice versa
      return follower._id === jwt.user._id;
    });
    return match;
  };
  handleChange = (comment) => (event) => {
    this.setState({ error: "" })//-> when user inserting a input after getting error it will vanish by itself 
    this.setState({ [comment]: event.target.value })
    console.log(this.state.comment)
  };
  clickFollowButton = callApi => {
    const userId = isAuthenticated().user._id;
    const token = isAuthenticated().token;

    callApi(userId, token, this.state.user._id).then(data => {
      if (data.error) {
        this.setState({ error: data.error });
      } else {
        this.setState({ user: data, following: !this.state.following });
      }
    });
  };

  init = userId => {
    const token = isAuthenticated().token;
    read(userId, token).then(data => {
      if (data.error) {
        this.setState({ redirectToSignin: true });
      } else {
        //  let following = this.checkFollow(data);
        this.setState({ user: data });
        // this.loadPosts(data._id);
        console.log(userId)
        getTwitbi(userId).then(data => {
          if (data.error) {
            this.setState({ redirectToSignin: true });
          } else {
            //  let following = this.checkFollow(data);
            this.setState({ twits: data.slice(0, 5) });
            // this.loadPosts(data._id);
            console.log(data)
          }
        });
      }
    });

  };

  loadPosts = userId => {
    const token = isAuthenticated().token;
    listByUser(userId, token).then(data => {
      if (data.error) {
        console.log(data.error);
      } else {
        this.setState({ posts: data });
      }
    });
  };

  componentDidMount() {
    const userId = this.props.match.params.userId;
    this.init(userId);
  }

  componentWillReceiveProps(props) {
    const userId = props.match.params.userId;
    this.init(userId);
  }
  commentForm = (comment) => (
    <form>
      <div className="form-group">
        <lable className="text-muted">Comment</lable>
        <input onChange={this.handleChange("comment")} type="text" className="form-control" value={comment} />
      </div>


      <button onClick={this.clickSubmit} className="btn btn-raised btn-primary">
        Submit
         </button>
    </form>
  )
  addComment(commentId) {
    const { comment } = this.state;
    // console.log("hello comment")

    const userId = isAuthenticated().user._id;
    if (userId.length !== 0) {
      /*const addcomment = {

        comment
      }*/
      const userId = isAuthenticated().user._id;
      //const token = isAuthenticated().token;
      const postId = commentId;
      const user = {
        userid: userId,
        // email,
        comment: this.state.comment,
        postid: postId
      }
      console.log(user)


      addcomment(user).then(data => {
        if (data.error) this.setState({ error: data.error });
        else
          this.setState({
            error: "",
            comment: "",
            open: true
          })
      })
    }
    else {
      this.setState({ error: "Please signin to comment" })
    }

  }
  removeComment(cid, tid) {
    const commentId = cid
    // console.log(tid)
    const twitId = tid;
    const user = {
      // userid: userId,
      // email,
      twitId,
      commentId,

    }
    removecomment(user).then(data => {
      if (data.error) this.setState({ error: data.error });
      else
        this.setState({
          error: "",

          open: true
        })
    })
    window.location.reload(false);

  }
  render() {
    const { redirectToSignin, user, posts } = this.state;
    if (redirectToSignin) return <Redirect to="/signin" />;

    const photoUrl = user._id
      ? `http://localhost:8080/user/photo/${
      user._id
      }?${new Date().getTime()}`
      : DefaultProfile;

    return (
      <div className="container-fluid">
        <h2 className="mt-5 mb-5">Profile</h2>
        <div className="row">
          <div>
            <div className="row">
              <div className="col-md-4">
                <img
                  style={{ height: "200px", width: "auto" }}
                  className="img-thumbnail"
                  src={photoUrl}
                  onError={i => (i.target.src = `${DefaultProfile}`)}
                  alt={user.name}
                />
              </div>

              <div className="col-md-5">
                <div className="lead mt-2">
                  <p>Hello {user.name}</p>
                  <p>Email: {user.email}</p>
                  <p>{`Joined ${new Date(
                    user.created
                  ).toDateString()}`}</p>
                </div>


              </div>
            </div>

          </div>
          <div> <div>
            {isAuthenticated().user &&
              isAuthenticated().user._id === user._id ? (
                <div className="d-inline-block">


                  { /*<DeleteUser userId={user._id} />*/}
                </div>
              ) : (
                <FollowProfileButton
                  following={this.state.following}
                  onButtonClick={this.clickFollowButton}
                />
              )}

            <div> <ProfileTabs
              followers={user.followers}
              following={user.following}
            /* posts={posts}*/
            /></div>
          </div>
            {this.state.twits.map((twit, i) => (
              <div>
                <div className="row">
                  <div className="col"><b>* Twits:</b>{twit.twit}</div>
                  <div className="col"><b>Twitted on:</b>{`Twitted ${new Date(
                    user.created
                  ).toDateString()}`}

                  </div>

                  <hr></hr>
                  <br></br>
                </div>
                <div className="row">
                  <div>

                  </div> <div>
                    <form>
                      <div className="form-group">
                        <lable className="text-muted">Comment</lable>
                        <input onChange={this.handleChange("comment")} type="text" className="form-control" value={this.state.comment} />
                      </div>

                      <button /*onClick={this.clickSubmit} */
                        onClick={() => this.addComment(twit._id)}
                        className="btn btn-raised btn-primary">
                        comment
         </button>
                    </form>

                  </div>

                </div>
                <b>View comments</b>
                <div>
                  {twit.comments.map((tw, i) => (
                    <div className="row">
                      <div className="col-4"><b> </b>{tw.comment}</div>
                      <div className="col-4"><b>posted By </b>{tw.postedBy.name}</div>

                      {isAuthenticated() && isAuthenticated().user.name === tw.postedBy.name
                        && (
                          <div className="col-2" style={{ color: "blue" }}>

                            <button /*onClick={this.clickSubmit} */
                              onClick={() => this.removeComment(tw._id, twit._id)}
                              className="btn btn-raised btn-warning">
                              remove comment
         </button>
                          </div>)}
                    </div>
                  ))}

                </div>
                <hr></hr>
              </div>
            ))}

          </div>
        </div>

      </div>
    );
  }
}

export default Profile;
