
import React, { Component } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import Twitter from "./twitter.js"
import Twitss1 from './twitss1.js'
import { signout, isAuthenticated } from "../auth";
//import { twit } from './api.js'
import { twiter, twits } from "./twitapi.js";

class Home extends Component {
  constructor() {
    super()
    this.state = {
      twit: "",
      postedBy: ``,
      twits1: [],
      error: ""
    };

  }
  isValid = () => {

    const isAuthenticated = () => {
      if (typeof window == "undefined") {
        return false;
      }

      if (localStorage.getItem("jwt")) {
        return JSON.parse(localStorage.getItem("jwt"));
      } else {
        return false;
      }
    };

    if (isAuthenticated().user === undefined) {
      this.setState({
        error: "Please signin to ",
        loading: false
      });
      return false;
    }
    if (this.state.twit.length === 0) {
      this.setState({ error: "Twit is required", loading: false });
      return false;
    }
    // email@domain.com


    return true;
  };

  handleChange = (twit) => (event) => {
    this.setState({ error: "" })//-> when user inserting a input after getting error it will vanish by itself 
    this.setState({ [twit]: event.target.value })

    console.log(this.state.twit)



  };

  clickSubmit = async (event) => {

    event.preventDefault()// to not to reload by defualt 

    console.log(this.state.postedBy)
    console.log(this.state.twit)


    const { twit, postedBy } = this.state;
    // now to create object and send it to the backend 

    if (this.isValid()) {
      const userId = `${isAuthenticated().user._id}`
      const twits = {
        twit,
        postedBy: userId,

      }

      console.log(twits)

      twiter(twits).then(data => {

        if (data.error) this.setState({ error: "error" });

        else
          this.setState({
            twits1: data,
            error: "",


            open: true
          })
      })
      console.log(this.state.twits1)
    }
    window.location.reload(false);
  };

  componentWillMount() {
    console.log(twits)
    twits().then(data => {
      if (data.error) {
        console.log(data.error);
      } else {
        this.setState({ twits1: data });
        console.log(data)
      }
    });
    console.log(this.state.twits1)
  }

  twitForm = (twit) => (
    <form>
      {
        isAuthenticated() && (
          <div>
            {/* {`${isAuthenticated().user._id}'s profile`}  */}
          </div>)
      }
      <div className="form-group">
        <b style={{ color: "red" }}>   {this.state.error} </b>
        <lable className="text-muted">Tweet here:</lable>



        <div> <input onChange={this.handleChange("twit")} type="text" placeholder="write something here ......." className="form-control" value={twit} style={{ height: "90px" }} /></div>


      </div>

      {/*isAuthenticated().user._id}*/}
      <button onClick={this.clickSubmit} className="btn btn-raised btn-primary">
        Submit
         </button>
    </form>
  )




  render() {

    const { twit } = this.state
    return (
      <div>
        <div className="row">
          <div className="col-4" >
            <div style={{ borderRight: "1px solid grey", height: "600px" }}>
              <Twitter />
            </div>
          </div>
          <div className="col-3">
            <div style={{ borderBottom: "1px solid grey" }}>
              {this.twitForm(twit)}
            </div>
            {(this.state.twits1.length !== 0) && (
              <div>
                <b> Recent Twits:</b>
                {this.state.twits1.map((twit, i) => (
                  <div className="row">
                    <div className="col"><b>Tweet:</b>{twit.twit}</div>
                    <div className="col"><b>Name:</b>{twit.postedBy.name}

                    </div>

                    <hr></hr>
                    <br></br>
                  </div>
                ))}
                <hr></hr>
              </div>)}
            {(this.state.twits1.length === 0) && (
              <div>
                Empty tweet

              </div>)}


          </div>
          <div className="col-3">
            <div style={{ borderLeft: "1px solid grey", height: "600px" }}>
              <Twitss1 />
            </div>


          </div>
        </div>

      </div >
    );
  }
}

export default Home;
