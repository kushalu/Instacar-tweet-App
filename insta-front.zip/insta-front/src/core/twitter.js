import React, { Component } from 'react';
import { searchtwitter } from "./twitapi";
import { Link } from "react-router-dom";
class Twitter extends Component {
  constructor() {
    super()
    this.state = {
      search: "",
      results: [],
      error: "",
      searched: false
    }
  }
  handleChange = (search) => (event) => {
    this.setState({ error: "" })//-> when user inserting a input after getting error it will vanish by itself 
    this.setState({ [search]: event.target.value })
  };
  clickSubmit = event => {
    event.preventDefault()// to not to reload by defualt 


    const { search } = this.state;
    // now to create object and send it to the backend 


    //console.log(user);

    /*signup(user).then(data => {
      if (data.error) this.setState({ error: data.error });
      else
        this.setState({
          error: "",
          search: "",
          open: true
        })
    })*/
    //const searchData = () => {
    // console.log(search, category);
    console.log(search)
    if (this.state.search.length !== 0) {
      searchtwitter({ search: search || undefined }).then(
        response => {
          if (response.error) {
            console.log(response.error);
          } else {
            this.setState({ results: response, searched: true, redirect: "true" });
          }
        }
      );
    }
    console.log(this.state.results)
    //};
  };

  // signup = (user) => {
  //   //  return fetch("http://localhost:8080/signup",
  //   return fetch(`${process.env.REACT_APP_API_URL}/signup`,
  //     {// we are using curly brace and the function as to return  ->> so used return keyword 
  //       method: "POST",
  //       headers: {
  //         Accept: "application/json",
  //         "Content-type": "application/json"
  //       },
  //       body: JSON.stringify(user)
  //     })
  //     .then(response => {
  //       return response.json()
  //     })
  //     .catch(err => console.log(err));
  // }
  twitForm = (search) => (
    <form>
      <div className="form-group">

        <input onChange={this.handleChange("search")} type="text" className="form-control" value={search} placeholder="Search by name" />
      </div>


      <button onClick={this.clickSubmit} className="btn btn-raised btn-primary">
        Submit
         </button>
    </form>
  )
  render() {
    const { search, error, open } = this.state
    return (
      <div className="container">


        {error}




        {this.twitForm(search)}
        {/* passing variables as arguments  in the above   */}
        {this.state.results.map((twit, i) => (
          <div className="row">
            <div className="col"><b>Name:</b>{twit.name}</div>
            <div className="col"><b>Email:</b>{twit.email}
              <Link
                to={`/user/${twit._id}`}
                className="btn btn-raised btn-danger btn-sm"
              >
                View Profile
                        </Link>
            </div>

            <hr></hr>
            <br></br>
          </div>
        ))}
        <div> </div>
      </div>
    );


  }
}
export default Twitter 