
import queryString from "query-string";
export const twiter = twits => {
  console.log(twits)
  //return fetch(`${process.env.REACT_APP_API_URL}/signup`, {
  return fetch(`http://localhost:8080/twit`, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(twits)
  })
    .then(response => {
      return response.json();
    })
    .catch(err => console.log(err));
};
export const twits = () => {
  return fetch(`http://localhost:8080/twits`, {
    method: "GET"
  })
    .then(response => {
      return response.json();
    })
    .catch(err => console.log(err));
};

export const searchtwitter = search => {
  const query = queryString.stringify(search);
  console.log("query", query);
  return fetch(`http://localhost:8080/users/search?${query}`, {
    method: "GET"
  })
    .then(response => {
      return response.json();
    })
    .catch(err => console.log(err));
};

export const searchtwitts = search => {
  const query = queryString.stringify(search);
  console.log("query", query);
  return fetch(`http://localhost:8080/twits/search?${query}`, {
    method: "GET"
  })
    .then(response => {
      return response.json();
    })
    .catch(err => console.log(err));
};