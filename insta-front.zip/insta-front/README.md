step1 : unzip
step2: npm install
step3: npm start